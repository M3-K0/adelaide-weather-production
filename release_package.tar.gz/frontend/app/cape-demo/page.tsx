'use client';

import React from 'react';
import { CAPEBadgeExample } from '../../components/CAPEBadgeExample';

export default function CAPEDemoPage() {
  return <CAPEBadgeExample />;
}
